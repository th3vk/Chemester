#define whiblu SetConsoleTextAttribute(Cons, (WORD) ((15 << 4)|3)); //����� ������, ����� ������
#define blared SetConsoleTextAttribute(Cons, (WORD) ((0 << 4)|12));  //������ ������, ������� ������
#define whired SetConsoleTextAttribute(Cons, (WORD) ((15 << 4)|12)); //����� ������, ������� ������
#define blablu SetConsoleTextAttribute(Cons, (WORD) ((0 << 4)|3)); //������ ������, ����� ������
#define def SetConsoleTextAttribute(Cons, (WORD) ((0 << 4)|15)); //����� �����, ������ ���
#include <iostream>
#include <math.h>
#include <vector>
#include <string>
#include <stdlib.h>
#include <Windows.h>
#include <fstream>

using namespace std;

void TurnBlue(); //��������� ������� ����, ����� ��� ��������� �������� ���� �����
void TurnRed(); 

int field [8][8]={ //������� ��-����� - �� 41 �� 48, ����� - �� 11 �� 18
{44,46,48,42,41,48,46,44}, 
{2,2,2,2,2,2,2,2},//����� - 2
{0,0,0,0,0,0,0,0}, //������ ������ - 0
{0,0,0,0,0,0,0,0}, 
{0,0,0,0,0,0,0,0}, 
{0,0,0,0,0,0,0,0},
{3,3,3,3,3,3,3,3},
{14,16,18,12,11,18,16,14}}; //������� ������������, � �������� ������ ������� ������ ������� ������� y-����������, ����� �-����������. 

vector <string> turns;
bool wclr=true; //white color 
bool red=true; //red figure
string turn;
bool kingmoved=false,mate=false,checkred=false,checkblue=false;
int x,y,x2,y2,x3,y3;
// K=king=1; Q=queen=2; R=rook=4; N=knight=6; B=bishop=8; p=pawn. ����� - ������� - ������, ������ - ����� - �����.

int ctoi(char num){
	switch(num){		//������� ����� ����� ������� ��� ��������� ���� char, ������� ����� ���� ������ ����� ���������� char �� string � char* � ����� � �����.
	case '1': return 0; 
	case '2': return 1; 
	case '3': return 2;
	case '4': return 3;
	case '5': return 4;
	case '6': return 5;
	case '7': return 6;
	case '8': return 7;
	case 'a': return 0;
	case 'b': return 1;
	case 'c': return 2;
	case 'd': return 3;
	case 'e': return 4;
	case 'f': return 5;
	case 'g': return 6;
	case 'h': return 7;
	}
}

void Checkcheck() {
	checkred = false;
	checkblue = false;
	int rkingx, rkingy, bkingx, bkingy;
	for (int i = 0; i < 8; i++) //������� ���������� �������� � ������ ������
		for (int j = 0; j < 8; j++)
			if (field[i][j] == 41) {
				rkingx = j;
				rkingy = i;
			}

	for (int i = 0; i < 8; i++)
		for (int j = 0; j < 8; j++)
			if (field[i][j] == 11) {
				bkingx = j;
				bkingy = i;
			}
	//�������� ������������ �������� ������
	int i = rkingy, j = rkingx;//���� ������ - ����� � �����
	do {
		i--;
		if (field[i][rkingx] == 14 || field[i][rkingx] == 12)
			checkred = true;
	} while (i > 0 && field[i][j] == 0);
	i = rkingy;
	do{
		i++;
		if (field[i][rkingx] == 14 || field[i][rkingx] == 12)
			checkred = true;
		}while (i < 7 && field[i][j] == 0);
	i = rkingy;
	do{
		j++;
		if (field[rkingy][j] == 14 || field[rkingy][j] == 12)
			checkred = true;
	} while (j < 7 && field[i][j] == 0);
	i = rkingy, j = rkingx;
	do{

		j--;
		if (field[rkingy][j] == 14 || field[rkingy][j] == 12)
			checkred = true;
	} while (j > 0 && field[i][j] == 0);
	i = rkingy, j = rkingx;
	do{	
		i--;
		j--;
		if (field[i][j] == 12 || field[i][j] == 18)  //��������� - ����� � �����
			checkred = true;
	} while (i > 0 && j > 0 && field[i][j] == 0);
	i = rkingy, j = rkingx;
	do{
		i++;
		j--;
		if (field[i][j] == 12 || field[i][j] == 18)
			checkred = true;
	} while (i < 7 && j>0 && field[i][j] == 0);
	i = rkingy, j = rkingx;
	do{
		i--;
		j++;
		if (field[i][j] == 12 || field[i][j] == 18)
			checkred = true;
	} while (i > 0 && j < 7 && field[i][j] == 0);
		i = rkingy, j = rkingx;
	do{
		i++;
		j++;
		if (field[i][j] == 12 || field[i][j] == 18)
			checkred = true;
		} while (i < 7 && j < 7 && field[i + 1][j + 1] == 0);
	i = rkingy, j = rkingx; //���� - ����� �
	if ((i < 7 && j < 6 && field[i + 1][j + 2] == 16) || (i < 6 && j < 7 && field[i + 2][j + 1] == 16) ||
		(i>1 && j < 7 && field[i - 2][j + 1] == 16) || (i>0 && j < 6 && field[i - 1][j + 2] == 16) ||
		(i < 6 && j>0 && field[i + 2][j - 1] == 16) || (i < 7 && j>1 && field[i + 1][j - 2] == 16) ||
		(i>1 && j>0 && field[i - 2][j - 1] == 16) || (i>0 && j>1 && field[i - 1][j - 2] == 16))
		checkred = true;

	i = rkingy, j = rkingx; //�����.
	if (field[i + 1][j + 1] == 3 || field[i + 1][j - 1] == 3) {
		checkred = true;
	}
	//�����
	i = bkingy, j = bkingx;
	do {
		//���� ������ - ����� � �����
		i--;
		if (field[i][bkingx] == 44 || field[i][bkingx] == 42)
			checkblue = true;
	} while (i > 0 && field[i][j] == 0);
	i = bkingy, j = bkingx;
	do {
		i++;
		if (field[i][bkingx] == 44 || field[i][bkingx] == 42)
			checkblue = true;
	} while (i < 7 && field[i][j] == 0);
	i = bkingy, j = bkingx;
	do {
		j++;
		if (field[bkingy][j] == 44 || field[bkingy][j] == 42)
			checkblue = true;
	} while (j < 7 && field[i][j] == 0);
	i = bkingy, j = bkingx;
	do {
		j--;
		if (field[bkingy][j] == 44 || field[bkingy][j] == 42)
			checkblue = true;
	} while (j > 0 && field[i][j] == 0);
	i = bkingy, j = bkingx;
	do {
		i--;
		j--;
		if (field[i][j] == 42 || field[i][j] == 48)  //��������� - ����� � �����
			checkblue = true;
	} while (i > 0 && j > 0 && field[i][j] == 0);
	i = bkingy, j = bkingx;
	do {
		i++;
		j--;
		if (field[i][j] == 42 || field[i][j] == 48)
			checkblue = true;
	} while (i < 7 && j>0 && field[i][j] == 0);
	i = bkingy, j = bkingx;
	do {
		i--;
		j++;
		if (field[i][j] == 42 || field[i][j] == 48)
			checkblue = true;
	} while (i > 0 && j < 7 && field[i - 1][j + 1] == 0);
	i = bkingy, j = bkingx;
	do{
				i++;
				j++;
				if (field[i][j]==42||field[i][j]==48)
					checkblue=true;
	} while (i < 7 && j < 7 && field[i][j] == 0);

		i=bkingy,j=bkingx; //���� - ����� �
		if ((i<7&&j<6&&field[i+1][j+2]==46)||(i<6&&j<7&&field[i+2][j+1]==46)||
			(i>1&&j<7&&field[i-2][j+1]==46)||(i>0&&j<6&&field[i-1][j+2]==46)||
			(i<6&&j>0&&field[i+2][j-1]==46)||(i<7&&j>1&&field[i+1][j-2]==46)||
			(i>1&&j>0&&field[i-2][j-1]==46)||(i>0&&j>1&&field[i-1][j-2]==46))
		checkblue=true;
		
		i=bkingy,j=bkingx; //�����.
		if (field[i-1][j+1]==2||field[i-1][j-1]==2){
			checkblue=true;
		}

	return;
}
void Matecheck()  { //������� �����. ����� ������� �������� ���� �����, ������� ������ ���.
	bool found = false;
	if (checkred) {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (field[i][j] == 2 || field[i][j] == 42 || field[i][j] == 44 || field[i][j] == 46 || field[i][j] == 48||field[i][j]==41) { //���-��� ����� ������ ��� �����, � � ���� ��� ���� ����� ����� ��-��� ���� � ��� ����� �������.
					switch (field[i][j]) { //������, ��������� ��� ��������� ���� ���� ���������� ����� ����� ���������, ���� �� ��� ��� ������� ������ ������ ��-��� ����
					case 2: { //�����
						if (field[i + 1][j] == 0) { //������ �������, ���� ��������
							x = j;
							y = i;
							x2 = j;
							y2 = i + 1;
							field[y][x] = 0;
							field[i + 1][x2] = 2;
							Checkcheck();
							field[y2][x2] = 0;
							field[y][x] = 2;
							if (!checkred) found = true; //������ if
						}
						if (field[i + 1][j + 1] == 3 || field[i + 1][j + 1] == 12 || field[i + 1][j + 1] == 14 || field[i + 1][j + 1] == 16 || field[i + 1][j + 1] == 18) {
							x = j; //������ �����, ���� �����
							y = i;
							x2 = j;
							y2 = i + 1;
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 2;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 2;
							if (!checkred) found = true;
						}
						if (field[i + 1][j - 1] == 3 || field[i + 1][j - 1] == 12 || field[i + 1][j - 1] == 14 || field[i + 1][j - 1] == 16 || field[i + 1][j - 1] == 18) {
							x = j;
							y = i;
							x2 = j;
							y2 = i + 1;
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 2;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 2;
							if (!checkred) found = true;
						}
						break;
					} //�����
					case 44: {
						x = j; //���� - ��������� ������ � ����� �� �����������, ��������� �� - � ������, ���� ����-�� �����
						y = i;
						x2 = j;
						y2 = i;
							while (y2 < 7 && field[y2 + 1][x2] == 0) {
								field[y2][x2] = 0; //������� ����� �� 1 � ����� �� �����������
								y2++;
								field[y2][x2] = 44;
								Checkcheck();
								if (!checkred) found = true;
							}
							if (y2 < 7 && (field[y2 + 1][x2] == 3 || field[y2 + 1][x2] == 12 || field[y2 + 1][x2] == 14 || field[y2 + 1][x2] == 16 || field[y2 + 1][x2] == 18)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2 + 1][x2] = 44;
								Checkcheck();
								field[y2 + 1][x2] = buf;
								field[y2][x2] = 44;
								if (!checkred) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 44; //�� �������� ������� ��� ��� ���� ����������
							
							x = j;
							y = i;
							x2 = j;
							y2 = i;
							while (y2 > 0 && field[y2 - 1][x2] == 0) {
								field[y2][x2] = 0;
								y2--;
								field[y2][x2] = 44;
								Checkcheck();
								if (!checkred) found = true;
							}
							if (y2 > 0 && (field[y2 - 1][x2] == 3 || field[y2 - 1][x2] == 12 || field[y2 - 1][x2] == 14 || field[y2 - 1][x2] == 16 || field[y2 - 1][x2] == 18)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2 - 1][x2] = 44;
								Checkcheck();
								field[y2 - 1][x2] = buf;
								field[y2][x2] = 44;
								if (!checkred) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 44;
						

							x = j;
							y = i;
							x2 = j;
							y2 = i;
							while (x2 < 7 && field[y2][x2 + 1] == 0) {
								field[y2][x2] = 0;
								x2++;
								field[y2][x2] = 44;
								Checkcheck();
								if (!checkred) found = true;
							}
							if (x2 < 7 && (field[y2][x2 + 1] == 3 || field[y2][x2 + 1] == 12 || field[y2][x2 + 1] == 14 || field[y2][x2 + 1] == 16 || field[y2][x2 + 1] == 18)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2][x2 + 1] = 44;
								Checkcheck();
								field[y2][x2 + 1] = buf;
								field[y2][x2] = 44;
								if (!checkred) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 44;
				
							x = j;
							y = i;
							x2 = j;
							y2 = i;
							while (x2 < 7 && field[y2][x2 - 1] == 0) {
								field[y2][x2] = 0;
								x2--;
								field[y2][x2] = 44;
								Checkcheck();
								if (!checkred) found = true;
							}
							if (x2 > 0 && (field[y2][x2 - 1] == 3 || field[y2][x2 - 1] == 12 || field[y2][x2 - 1] == 14 || field[y2][x2 - 1] == 16 || field[y2][x2 - 1] == 18)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2][x2 - 1] = 44;
								Checkcheck();
								field[y2][x2 - 1] = buf;
								field[y2][x2] = 44;
								if (!checkred) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 44;
						break;
					}
					case 48: {//�����
						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2 < 7 && field[y2 + 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2++;
							field[y2][x2] = 48;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 < 7 && y2 < 7 && (field[y2 + 1][x2 + 1] == 3 || field[y2 + 1][x2 + 1] == 12 || field[y2 + 1][x2 + 1] == 14 || field[y2 + 1][x2 + 1] == 16 || field[y2 + 1][x2 + 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 + 1] = 48;
							Checkcheck();
							field[y2 + 1][x2 + 1] = buf;
							field[y2][x2] = 48;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 48;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2>0 && field[y2 - 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2--;
							field[y2][x2] = 48;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 < 7 && y2>0 && (field[y2 - 1][x2 + 1] == 3 || field[y2 - 1][x2 + 1] == 12 || field[y2 - 1][x2 + 1] == 14 || field[y2 - 1][x2 + 1] == 16 || field[y2 - 1][x2 + 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 + 1] = 48;
							Checkcheck();
							field[y2 - 1][x2 + 1] = buf;
							field[y2][x2] = 48;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 48;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 < 7 && field[y2 + 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2++;
							field[y2][x2] = 48;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 > 0 && y2 < 7 && (field[y2 + 1][x2 - 1] == 3 || field[y2 + 1][x2 - 1] == 12 || field[y2 + 1][x2 - 1] == 14 || field[y2 + 1][x2 - 1] == 16 || field[y2 + 1][x2 - 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 - 1] = 48;
							Checkcheck();
							field[y2 + 1][x2 - 1] = buf;
							field[y2][x2] = 48;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 48;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 > 0 && field[y2 - 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2--;
							field[y2][x2] = 48;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 > 0 && y2 > 0 && (field[y2 - 1][x2 - 1] == 3 || field[y2 - 1][x2 - 1] == 12 || field[y2 - 1][x2 - 1] == 14 || field[y2 - 1][x2 - 1] == 16 || field[y2 - 1][x2 - 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 - 1] = 48;
							Checkcheck();
							field[y2 - 1][x2 - 1] = buf;
							field[y2][x2] = 48;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 48;
						break;
					}
					case 46: { //����
						x = j; //8 ��������� ����� �� ��������.
						y = i;
						x2 = j + 1;
						y2 = i + 2;
						if (x2 < 7 && y2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						x2 = j - 1;
						y2 = i + 2;
						if (x2 > 0 && y2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						x2 = j + 1;
						y2 = i - 2;
						if (x2 < 7 && y2>0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						x2 = j - 1;
						y2 = i - 2;
						if (x2 > 0 && y2 > 0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						x2 = j - 2;
						y2 = i - 1;
						if (x2 > 0 && y2 > 0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						x2 = j + 2;
						y2 = i - 1;
						if (x2 < 7 && y2>0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						x2 = j - 2;
						y2 = i + 1;
						if (x2 > 0 && y2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						x2 = j + 2;
						y2 = i + 1;
						if (x2 < 7 && y2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48 && field[y2][x2] != 41) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 46;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 46;
							if (!checkred) found = true;
						}
						break;
					}
					case  42: { //�����
						x = j; //���� - ��������� ������ � ����� �� �����������, ��������� �� - � ������, ���� ����-�� �����. ������� ���������, ����� �����������, ����� ���������
						y = i;
						x2 = j;
						y2 = i;
							while (y2 < 7 && field[y2 + 1][x2] == 0) {
								field[y2][x2] = 0;
								y2++;
								field[y2][x2] = 42;
								Checkcheck();
								if (!checkred) found = true;
							}
							if (y2 < 7 && (field[y2 + 1][x2] == 3 || field[y2 + 1][x2] == 12 || field[y2 + 1][x2] == 14 || field[y2 + 1][x2] == 16 || field[y2 + 1][x2] == 18)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2 + 1][x2] = 42;
								Checkcheck();
								field[y2 + 1][x2] = buf;
								field[y2][x2] = 42;
								if (!checkred) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 42;
						
							x = j;
							y = i;
							x2 = j;
							y2 = i;
						while (y2 > 0 && field[y2 - 1][x2] == 0) {
							field[y2][x2] = 0;
							y2--;
							field[y2][x2] = 42;
							Checkcheck();
							if (!checkred) found = true;
						}
						if (y2 > 0&&(field[y2 - 1][x2] == 3 || field[y2 - 1][x2] == 12 || field[y2 - 1][x2] == 14 || field[y2 - 1][x2] == 16 || field[y2 - 1][x2] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2] = 42;
							Checkcheck();
							field[y2 - 1][x2] = buf;
							field[y2][x2] = 42;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 42;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && field[y2][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							field[y2][x2] = 42;
							Checkcheck();
							if (!checkred) found = true;
						}
						if (x2 < 7 && (field[y2][x2 + 1] == 3 || field[y2][x2 + 1] == 12 || field[y2][x2 + 1] == 14 || field[y2][x2 + 1] == 16 || field[y2][x2 + 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2][x2 + 1] = 42;
							Checkcheck();
							field[y2][x2 + 1] = buf;
							field[y2][x2] = 42;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 42;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && field[y2][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							field[y2][x2] = 42;
							Checkcheck();
							if (!checkred) found = true;
						}
						if (x2 > 0 && (field[y2][x2 - 1] == 3 || field[y2][x2 - 1] == 12 || field[y2][x2 - 1] == 14 || field[y2][x2 - 1] == 16 || field[y2][x2 - 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2][x2 - 1] = 42;
							Checkcheck();
							field[y2][x2 - 1] = buf;
							field[y2][x2] = 42;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 42;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2 < 7 && field[y2 + 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2++;
							field[y2][x2] = 42;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 < 7 && y2 < 7 && (field[y2 + 1][x2 + 1] == 3 || field[y2 + 1][x2 + 1] == 12 || field[y2 + 1][x2 + 1] == 14 || field[y2 + 1][x2 + 1] == 16 || field[y2 + 1][x2 + 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 + 1] = 42;
							Checkcheck();
							field[y2 + 1][x2 + 1] = buf;
							field[y2][x2] = 42;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 42;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2>0 && field[y2 - 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2--;
							field[y2][x2] = 42;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 < 7 && y2>0 && (field[y2 - 1][x2 + 1] == 3 || field[y2 - 1][x2 + 1] == 12 || field[y2 - 1][x2 + 1] == 14 || field[y2 - 1][x2 + 1] == 16 || field[y2 - 1][x2 + 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 + 1] = 42;
							Checkcheck();
							field[y2 - 1][x2 + 1] = buf;
							field[y2][x2] = 42;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 42;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 < 7 && field[y2 + 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2++;
							field[y2][x2] = 42;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 > 0 && y2 < 7 && (field[y2 + 1][x2 - 1] == 3 || field[y2 + 1][x2 - 1] == 12 || field[y2 + 1][x2 - 1] == 14 || field[y2 + 1][x2 - 1] == 16 || field[y2 + 1][x2 - 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 - 1] = 42;
							Checkcheck();
							field[y2 + 1][x2 - 1] = buf;
							field[y2][x2] = 42;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 42;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 > 0 && field[y2 - 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2--;
							field[y2][x2] = 42;
							Checkcheck();
							if (!checkred) found = true;
						}if (x2 > 0 && y2 > 0 && (field[y2 - 1][x2 - 1] == 3 || field[y2 - 1][x2 - 1] == 12 || field[y2 - 1][x2 - 1] == 14 || field[y2 - 1][x2 - 1] == 16 || field[y2 - 1][x2 - 1] == 18)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 - 1] = 42;
							Checkcheck();
							field[y2 - 1][x2 - 1] = buf;
							field[y2][x2] = 42;
							if (!checkred) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 42;
						break;
					}
					case 41: { //������, �������. 8 ��������� �����, ������� �� ���������.
						x = j;
						y = i;
						x2 = j - 1;
						y2 = i;
						if (x2 > 0 && y2 > 0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}

						x = j;
						y = i;
						x2 = j - 1;
						y2 = i;
						if (x2 > 0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}
						x = j;
						y = i;
						x2 = j - 1;
						y2 = i + 1;
						if (x2 > 0 && y2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}
						x = j;
						y = i;
						x2 = j;
						y2 = i + 1;
						if (y2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}
						x = j;
						y = i;
						x2 = j + 1;
						y2 = i + 1;
						if (x2 < 7 && y2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}
						x = j;
						y = i;
						x2 = j + 1;
						y2 = i;
						if (x2 < 7 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}
						x = j;
						y = i;
						x2 = j + 1;
						y2 = i - 1;
						if (x2 < 7 && y>0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}
						x = j;
						y = i;
						x2 = j;
						y2 = i - 1;
						if (y2 > 0 && field[y2][x2] != 2 && field[y2][x2] != 42 && field[y2][x2] != 44 && field[y2][x2] != 46 && field[y2][x2] != 48) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 41;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 41;
							if (!checkred) found = true;
						}
						break;
					}
					}
				}
			}
		}

		if (!found) mate = true;
	}
	//___________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
	if (checkblue){
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (field[i][j] == 3 || field[i][j] == 12 || field[i][j] == 14 || field[i][j] == 16 || field[i][j] == 18||field[i][j]==11) { //���-��� ����� ������ ��� �����, � � ���� ��� ���� ����� ����� ��-��� ���� � ��� ����� �������.
					switch (field[i][j]) { //������, ��������� ��� ��������� ���� ���� ���������� ����� ����� ���������, ���� �� ��� ��� ������� ������ ������ ��-��� ����
					case 3: { //�����
						if (field[i - 1][j] == 0) { //������ �������, ���� ��������
							x = j;
							y = i;
							x2 = j;
							y2 = i - 1;
							field[y][x] = 0;
							field[i - 1][x2] = 3;
							Checkcheck();
							field[y2][x2] = 0;
							field[y][x] = 3;
							if (!checkblue) found = true; //������ if
						}
						if (field[i - 1][j + 1] == 2 || field[i - 1][j + 1] == 42 || field[i - 1][j + 1] == 44 || field[i - 1][j + 1] == 46 || field[i - 1][j + 1] == 48) {
							x = j; //������ �����, ���� �����
							y = i;
							x2 = j;
							y2 = i - 1;
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 3;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 3;
							if (!checkblue) found = true;
						}
						if (field[i - 1][j - 1] == 2 || field[i - 1][j - 1] == 42 || field[i - 1][j - 1] == 44 || field[i - 1][j - 1] == 46 || field[i - 1][j - 1] == 48) {
							x = j;
							y = i;
							x2 = j;
							y2 = i - 1;
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 3;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 3;
							if (!checkblue) found = true;
						}
						break;
					} //�����
					case 14: {
						x = j; //���� - ��������� ������ � ����� �� �����������, ��������� �� - � ������, ���� ����-�� �����
						y = i;
						x2 = j;
						y2 = i;
							while (y2 < 7 && field[y2 + 1][x2] == 0) {
								field[y2][x2] = 0;
								y2++;
								field[y2][x2] = 14;
								Checkcheck();
								if (!checkblue) found = true;
							}
							if (y2 < 7 && (field[y2 + 1][x2] == 2 || field[y2 + 1][x2] == 42 || field[y2 + 1][x2] == 44 || field[y2 + 1][x2] == 46 || field[y2 + 1][x2] == 48)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2 + 1][x2] = 14;
								Checkcheck();
								field[y2 + 1][x2] = buf;
								field[y2][x2] = 14;
								if (!checkblue) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 14;						

							x = j;
							y = i;
							x2 = j;
							y2 = i;
							while (y2 > 0 && field[y2 - 1][x2] == 0) {
								field[y2][x2] = 0;
								y2--;
								field[y2][x2] = 14;
								Checkcheck();
								if (!checkblue) found = true;
							}
							if (y2 > 0 && (field[y2 - 1][x2] == 2 || field[y2 - 1][x2] == 42 || field[y2 - 1][x2] == 44 || field[y2 - 1][x2] == 46 || field[y2 - 1][x2] == 48)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2 - 1][x2] = 14;
								Checkcheck();
								field[y2 - 1][x2] = buf;
								field[y2][x2] = 14;
								if (!checkblue) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 14;
						
							x = j;
							y = i;
							x2 = j;
							y2 = i;
							while (x2 < 7 && field[y2][x2 + 1] == 0) {
								field[y2][x2] = 0;
								x2++;
								field[y2][x2] = 14;
								Checkcheck();
								if (!checkblue) found = true;
							}
							if (x2 < 7 && (field[y2][x2 + 1] == 2 || field[y2][x2 + 1] == 42 || field[y2][x2 + 1] == 44 || field[y2][x2 + 1] == 46 || field[y2][x2 + 1] == 48)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2][x2 + 1] = 14;
								Checkcheck();
								field[y2][x2 + 1] = buf;
								field[y2][x2] = 14;
								if (!checkblue) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 14;
						
							 x = j;
							 y = i;
							 x2 = j;
							 y2 = i;
							while (x2 < 7 && field[y2][x2 - 1] == 0) {
								field[y2][x2] = 0;
								x2--;
								field[y2][x2] = 14;
								Checkcheck();
								if (!checkblue) found = true;
							}
							if (x2 > 0 && (field[y2][x2 - 1] == 2 || field[y2][x2 - 1] == 42 || field[y2][x2 - 1] == 44 || field[y2][x2 - 1] == 46 || field[y2][x2 - 1] == 48)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2][x2 - 1] = 14;
								Checkcheck();
								field[y2][x2 - 1] = buf;
								field[y2][x2] = 14;
								if (!checkblue) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 14;
						break;
					}
					case 18: {//�����
						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2 < 7 && field[y2 + 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2++;
							field[y2][x2] = 18;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 < 7 && y2 < 7 && (field[y2 + 1][x2 + 1] == 2 || field[y2 + 1][x2 + 1] == 42 || field[y2 + 1][x2 + 1] == 44 || field[y2 + 1][x2 + 1] == 46 || field[y2 + 1][x2 + 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 + 1] = 18;
							Checkcheck();
							field[y2 + 1][x2 + 1] = buf;
							field[y2][x2] = 18;
							if (!checkblue) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 18;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2>0 && field[y2 - 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2--;
							field[y2][x2] = 18;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 < 7 && y2>0 && (field[y2 - 1][x2 + 1] == 2 || field[y2 - 1][x2 + 1] == 42 || field[y2 - 1][x2 + 1] == 44 || field[y2 - 1][x2 + 1] == 46 || field[y2 - 1][x2 + 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 + 1] = 18;
							Checkcheck();
							field[y2 - 1][x2 + 1] = buf;
							field[y2][x2] = 18;
							if (!checkblue) found = true;
						}	field[y2][x2] = 0;
						field[y][x] = 18;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 < 7 && field[y2 + 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2++;
							field[y2][x2] = 18;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 > 0 && y2 < 7 && (field[y2 + 1][x2 - 1] == 2 || field[y2 + 1][x2 - 1] == 42 || field[y2 + 1][x2 - 1] == 44 || field[y2 + 1][x2 - 1] == 46 || field[y2 + 1][x2 - 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 - 1] = 18;
							Checkcheck();
							field[y2 + 1][x2 - 1] = buf;
							field[y2][x2] = 18;
							if (!checkblue) found = true;
						}	field[y2][x2] = 0;
						field[y][x] = 18;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 > 0 && field[y2 - 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2--;
							field[y2][x2] = 18;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 > 0 && y2 > 0 && (field[y2 - 1][x2 - 1] == 2 || field[y2 - 1][x2 - 1] == 42 || field[y2 - 1][x2 - 1] == 44 || field[y2 - 1][x2 - 1] == 46 || field[y2 - 1][x2 - 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 - 1] = 18;
							Checkcheck();
							field[y2 - 1][x2 - 1] = buf;
							field[y2][x2] = 18;
							if (!checkblue) found = true;
						}	field[y2][x2] = 0;
						field[y][x] = 18;
						break;
					}
					case 16: { //����
						x = j; //8 ��������� ����� �� ��������.
						y = i;
						x2 = j + 1;
						y2 = i + 2;
						if (x2 < 7 && y2 < 7 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						x2 = j - 1;
						y2 = i + 2;
						if (x2 > 0 && y2 < 7 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						x2 = j + 1;
						y2 = i - 2;
						if (x2 < 7 && y2>0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						x2 = j - 1;
						y2 = i - 2;
						if (x2 > 0 && y2 > 0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						x2 = j - 2;
						y2 = i - 1;
						if (x2 > 0 && y2 > 0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						x2 = j + 2;
						y2 = i - 1;
						if (x2 < 7 && y2>0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						x2 = j - 2;
						y2 = i + 1;
						if (x2 > 0 && y2 < 7 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						x2 = j + 2;
						y2 = i + 1;
						if (x2 < 7 && y2 < 7 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18 && field[y2][x2] != 11) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 16;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 16;
							if (!checkblue) found = true;
						}
						break;
					}
					case  12: { //�����
						x = j; //���� - ��������� ������ � ����� �� �����������, ��������� �� - � ������, ���� ����-�� �����. ������� ���������, ����� �����������, ����� ���������
						y = i;
						x2 = j;
						y2 = i;
							while (y2 < 7 && field[y2 + 1][x2] == 0) {
								field[y2][x2] = 0;
								y2++;
								field[y2][x2] = 12;
								Checkcheck();
								if (!checkblue) found = true;
							}
							if (y2 < 7 && (field[y2 + 1][x2] == 2 || field[y2 + 1][x2] == 42 || field[y2 + 1][x2] ==44 || field[y2 + 1][x2] == 46 || field[y2 + 1][x2] == 48)) {
								int buf = field[y2][x2];
								field[y2][x2] = 0;
								field[y2 + 1][x2] = 12;
								Checkcheck();
								field[y2 + 1][x2] = buf;
								field[y2][x2] = 12;
								if (!checkblue) found = true;
							}
							field[y2][x2] = 0;
							field[y][x] = 12;
						
							x = j;
							y = i;
							x2 = j;
							y2 = i;
						while (y2 > 0 && field[y2 - 1][x2] == 0) {
							field[y2][x2] = 0;
							y2--;
							field[y2][x2] = 12;
							Checkcheck();
							if (!checkblue) found = true;
						}
						if (y2 > 0&&(field[y2 - 1][x2] == 2 || field[y2 - 1][x2] == 42 || field[y2 - 1][x2] == 44 || field[y2 - 1][x2] == 46 || field[y2 - 1][x2] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2] = 12;
							Checkcheck();
							field[y2 - 1][x2] = buf;
							field[y2][x2] = 12;
							if (!checkblue) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 12;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && field[y2][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							field[y2][x2] = 12;
							Checkcheck();
							if (!checkblue) found = true;
						}
						if (x2 < 7 && (field[y2][x2 + 1] == 2 || field[y2][x2 + 1] == 42 || field[y2][x2 + 1] == 44 || field[y2][x2 + 1] == 46 || field[y2][x2 + 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2][x2 + 1] = 12;
							Checkcheck();
							field[y2][x2 + 1] = buf;
							field[y2][x2] = 12;
							if (!checkblue) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 12;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && field[y2][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							field[y2][x2] = 12;
							Checkcheck();
							if (!checkblue) found = true;
						}
						if (x2 > 0 && (field[y2][x2 - 1] == 2 || field[y2][x2 - 1] == 42 || field[y2][x2 - 1] == 44 || field[y2][x2 - 1] == 46 || field[y2][x2 - 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2][x2 - 1] = 12;
							Checkcheck();
							field[y2][x2 - 1] = buf;
							field[y2][x2] = 12;
							if (!checkblue) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 12;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2 < 7 && field[y2 + 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2++;
							field[y2][x2] = 12;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 < 7 && y2 < 7 && (field[y2 + 1][x2 + 1] == 2 || field[y2 + 1][x2 + 1] == 42 || field[y2 + 1][x2 + 1] == 44 || field[y2 + 1][x2 + 1] == 46 || field[y2 + 1][x2 + 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 + 1] = 12;
							Checkcheck();
							field[y2 + 1][x2 + 1] = buf;
							field[y2][x2] = 12;
							if (!checkblue) found = true;
						}field[y2][x2] = 0;
						field[y][x] = 12;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 < 7 && y2>0 && field[y2 - 1][x2 + 1] == 0) {
							field[y2][x2] = 0;
							x2++;
							y2--;
							field[y2][x2] = 12;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 < 7 && y2>0 && (field[y2 - 1][x2 + 1] == 2 || field[y2 - 1][x2 + 1] == 42 || field[y2 - 1][x2 + 1] == 44 || field[y2 - 1][x2 + 1] == 46 || field[y2 - 1][x2 + 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 + 1] = 12;
							Checkcheck();
							field[y2 - 1][x2 + 1] = buf;
							field[y2][x2] = 12;
							if (!checkblue) found = true;
						}field[y2][x2] = 0;
						field[y][x] = 12;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 < 7 && field[y2 + 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2++;
							field[y2][x2] = 12;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 > 0 && y2 < 7 && (field[y2 + 1][x2 - 1] == 2 || field[y2 + 1][x2 - 1] == 42 || field[y2 + 1][x2 - 1] == 44 || field[y2 + 1][x2 - 1] == 46 || field[y2 + 1][x2 - 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 + 1][x2 - 1] = 12;
							Checkcheck();
							field[y2 + 1][x2 - 1] = buf;
							field[y2][x2] = 12;
							if (!checkblue) found = true;
						}field[y2][x2] = 0;
						field[y][x] = 12;

						x = j;
						y = i;
						x2 = j;
						y2 = i;
						while (x2 > 0 && y2 > 0 && field[y2 - 1][x2 - 1] == 0) {
							field[y2][x2] = 0;
							x2--;
							y2--;
							field[y2][x2] = 12;
							Checkcheck();
							if (!checkblue) found = true;
						}if (x2 > 0 && y2 > 0 && (field[y2 - 1][x2 - 1] == 2 || field[y2 - 1][x2 - 1] == 42 || field[y2 - 1][x2 - 1] == 44 || field[y2 - 1][x2 - 1] == 46 || field[y2 - 1][x2 - 1] == 48)) {
							int buf = field[y2][x2];
							field[y2][x2] = 0;
							field[y2 - 1][x2 - 1] = 12;
							Checkcheck();
							field[y2 - 1][x2 - 1] = buf;
							field[y2][x2] = 12;
							if (!checkblue) found = true;
						}
						field[y2][x2] = 0;
						field[y][x] = 12;
						break;
					}
					case 11: { //������, �������. 8 ��������� �����, ������� �� ���������.
						x = j;
						y = i;
						x2 = j - 1;
						y2 = i - 1;
						if (x2 > 0 && y2 > 0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 11;
							if (!checkblue) found = true;
						}
						x = j;
						y = i;
						x2 = j - 1;
						y2 = i;
						if (x2 > 0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 11;
							if (!checkblue) found = true;
						}
						x = j;
						y = i;
						x2 = j - 1;
						y2 = i + 1;
						if (x2 > 0 && y2 < 7 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 11;
							if (!checkblue) found = true;
						}
						x = j;
						y = i;
						x2 = j;
						y2 = i + 1;
						if (y2 < 7 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 11;
							if (!checkblue) found = true;
						}
						x = j;
						y = i;
						x2 = j + 1;
						y2 = i + 1;
						if (x2 < 7 && y2 < 7 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 11;
							if (!checkblue) found = true;
						}
						x = j;
						y = i;
						x2 = j + 1;
						y2 = i;
						if (x2 < 7 &&  field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 11;
							if (!checkblue) found = true;
						}
						x = j;
						y = i;
						x2 = j + 1;
						y2 = i - 1;
						if (x2 < 7 && y>0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x] = 11;
							if (!checkblue) found = true;
						}
						x = j;
						y = i;
						x2 = j;
						y2 = i - 1;
						if (y2 > 0 && field[y2][x2] != 3 && field[y2][x2] != 12 && field[y2][x2] != 14 && field[y2][x2] != 16 && field[y2][x2] != 18) {
							int buf = field[y2][x2];
							field[y][x] = 0;
							field[y2][x2] = 11;
							Checkcheck();
							field[y2][x2] = buf;
							field[y][x2] = 11;
							if (!checkblue) found = true;
						}
						break;
					}
					}
				}
			}
		}

		if (!found) mate = true;
	}
	return;
}


bool Bad(string turn,int who){ //who: 1-red, 2-blue
	if(turn.length()!=5){
		return true; //����� ����� ������� ����� 5 - ��������������������-��������������������
	}
	if(turn[0]!='a'&&turn[0]!='b'&&turn[0]!='c'&&turn[0]!='d'&&turn[0]!='e'&&turn[0]!='f'&&turn[0]!='g'&&turn[0]!='h'&&turn[3]!='a'&&turn[3]!='b'&&turn[3]!='c'&&turn[3]!='d'&&turn[3]!='e'&&turn[3]!='f'&&turn[3]!='g'&&turn[3]!='h'){
		return true; //��������� ������ �� a �� h
	}
	if(turn[1]!='1'&&turn[1]!='2'&&turn[1]!='3'&&turn[1]!='4'&&turn[1]!='5'&&turn[1]!='6'&&turn[1]!='7'&&turn[1]!='8'&&turn[4]!='1'&&turn[4]!='2'&&turn[4]!='3'&&turn[4]!='4'&&turn[4]!='5'&&turn[4]!='6'&&turn[4]!='7'&&turn[4]!='8'){
		return true; //����������� ������ �� 1 �� 8
	}
	if (((field[y][x]==3)||(field[y][x]>10 && field[y][x]<19))&&who==1)
		return true;

	if (((field[y][x]==2)||(field[y][x]>40 && field[y][x]<49))&&who==2)
		return true;

	if (field[y][x]==2||field[y][x]==3){ //�����
		if (field[y2][x2]==0&&x2==x&&((y2-y==1&&who==1)||(y-y2==1&&who==2))) //�� ���� ��������� ������
			return false;		
		if((field[y2][x2]==0&&x2==x&&abs(y2-y)==2&&(y==1||y==6))&&((who==1&&field[y2+1][x2]==0)||(who==2&&field[y2+1][x2]==0))) //�� ��� ��������� ������
			return false;		
		if(field[y2][x2]!=0&&abs(x2-x)==abs(y2-y)==1) //�� ��������� - ������ �����
			return false;		
	}
	if (field[y][x]==14||field[y][x]==44){ //�����. �������� �� ����������� � �� �������� �� ����� ���
		if (x<x2&&y==y2){
			for (int i=x+1;i<x2-1;i++){
				if (field[y][i]!=0)
					return true;				
			}
		}
		if (x>x2&&y==y2){
			for (int i=x2+1;i<x-1;i++){
				if (field[y][i]!=0)
					return true;				
			}
		}
		if (x==x2&&y<y2){
			for (int i=y+1;i<y2-1;i++){
				if (field[i][x]!=0)
					return true;				
			}
		}
		if (x==x2&&y>y2){
			for (int i=y2;i<y-1;i++){
				if (field[i][x]!=0)
					return true;    //��� 4 ��������� ��� �� ���� ��� ������				
			}
		}
		if (x!=x2&&y!=y2)
			return true;
	return false;
	}
	if (field[y][x]==16||field[y][x]==46){ //����. ���� ������ ��������� ��� ����� ��������� - ������ �.
		if ((abs(x2-x)==1&&abs(y2-y)==2) || (abs(x2-x)==2&&abs(y2-y)==1)){
			return false;
		}
	}
	if (field[y][x]==18||field[y][x]==48){//�����. ����� �������� �� ����������� � ��������������, �.�. �������� �� ����������� ����� �������� �� ���������. 
		if (abs(x2-x)==abs(y2-y)){
			if (x<x2&&y<y2){
			int i=x; 
			int j=y;
			while(i<x2-1&&j<y2-1){
				i++;
				j++;
				if (field[j][i]!=0)			
				return true;			}
			}
			if (x>x2&&y<y2){
			int i=x;
			int j=y;
			while(i>x2+1&&j<y2-1){
				i--;
				j++;
				if (field[j][i]!=0)			
				return true;			}				
			}
			if (x<x2&&y>y2){
			int i=x;
			int j=y;
			while(i<x2-1&&j>y2+1){
				i++;
				j--;
				if (field[j][i]!=0)			
				return true;			}				
			}
			if (x>x2&&y>y2){
			int i=x;
			int j=y;
			while(i>x2+1&&j>y2+1){
				i--;
				j--;
				if (field[j][i]!=0)			
				return true;			}
			}
			return false;
		}
	}
	if (field[y][x]==12||field[y][x]==42){ //�����-���� ��� ���� ���������.
		if (abs(x2-x)==abs(y2-y)||y2==y||x2==x){
		if (x<x2&&y==y2){
			for (int i=x+1;i<x2;i++)
				if (field[y][i]!=0)
					return true;				}
		if (x>x2&&y==y2){
			for (int i=x2+1;i<x;i++)
				if (field[y][i]!=0)
					return true;				}
		if (x==x2&&y<y2){
			for (int i=y+1;i<y2;i++)
				if (field[i][x]!=0)
					return true;				}
		if (x==x2&&y>y2){
			for (int i=y2+1;i<y;i++)
				if (field[i][x]!=0)
					return true;    			}
		if (x<x2&&y<y2){
			int i=x;
			int j=y;
			while(i<x2-1&&j<y2-1){
				i++;
				j++;
				if (field[j][i]!=0)			
				return true;		}
			}
			if (x>x2&&y<y2){
			int i=x;
			int j=y;
			while(i>x2+1&&j<y2-1){
				i--;
				j++;
				if (field[j][i]!=0)			
				return true;		}				
			}
			if (x<x2&&y>y2){
			int i=x;
			int j=y;
			while(i<x2-1&&j>y2+1){
				i++;
				j--;
				if (field[j][i]!=0)			
				return true;		}				
			}
			if (x>x2&&y>y2){
			int i=x;
			int j=y;
			while(i>x2+1&&j>y2+1){
				i--;
				j--;
				if (field[j][i]!=0)			
				return true;		}
			}
		return false;
	}
	}
		if(field[y][x]==11||field[y][x]==41){ //�� � ������. ���� ������ � ����� ������� ���� ���������. TODO: ��������� �� ������� 00 � 000
			if (abs(x-x2)<=1&&abs(y-y2)<=1){
				kingmoved=true;
				return false;
			}
			if ((x==4&&y==0)||(x==4&&y==7)&&!kingmoved){
				if (field[0][5]==0&&field[0][6]==0&&(field[0][7]==14)){
					kingmoved=true;
					return false;
				}
				if (field[0][3]==0&&field[0][2]==0&&field[0][1]==0&&(field[0][0]==14)){
					kingmoved=true;
					return false;
				}
			}
			return true;
		}
	return true;
}	

bool Teammate(int who){
	if (((field[y2][x2]>40&&field[y2][x2]<49)||(field[y2][x2]==2))&&who==1){
		return true;
	}
	if (((field[y2][x2]==3)||(field[y2][x2]>10&&field[y2][x2]<19))&&who==2){
		return true;
	}
	return false;
}

void PrintField(){
	char figure;
	system("cls");
	HANDLE Cons = GetStdHandle(STD_OUTPUT_HANDLE);  //��, WinApi. ����� cons - ����� ������������ ������, �.�. � �������
	def;
	cout<<"    a  b  c  d  e  f  g  h "<<endl<<endl;
	SetConsoleTextAttribute(Cons, (WORD) (15|0));
	for(int i=0;i<8;i++){
		def;
		cout<<(i+1)<<' '<<' ';
		for (int j=0;j<8;j++){
			switch (field[i][j]){				
				case 44:{red=true; figure='R'; break;}
				case 41:{red=true; figure='K'; break;}
				case 42:{red=true; figure='Q'; break;}				
				case 46:{red=true; figure='N'; break;}				
				case 48:{red=true; figure='B'; break;} //�������, ��-�����
				case 2:{red=true; figure='p'; break;} //������� �����
				
				case 14:{red=false; figure='R'; break;}
				case 11:{red=false; figure='K'; break;}
				case 12:{red=false; figure='Q'; break;}				
				case 16:{red=false; figure='N'; break;}				
				case 18:{red=false; figure='B'; break;} //�����, ��-�����
				case 3:{red=false; figure='p'; break;} //����� �����

				default:{figure=' '; break;}
			}
			(i+j)%2==0?wclr=true:wclr=false; //�������� ���� ������ ������ � ������ ����. ����� ���������� ������ ������ � define, ���, �������
			if(red){
				if(wclr){
					whired;
				}else{blared;}
			}else{
				if(wclr){
					whiblu;
				}else{
					blablu}
			}
			cout<<' '<<figure<<' ';
		}
		cout<<endl;
	}
	def;
	cout<<"    a  b  c  d  e  f  g  h "<<endl<<endl;
	if (checkred){
		blared;
		cout<< "WARNING! RED KING IS UNDER ATTACK!"<<endl<<endl;
	}
	if (checkblue){
		blablu;
		cout<< "WARNING! BLUE KING IS UNDER ATTACK!"<<endl<<endl;
	}

}


void GG(int loser) {
	PrintField();
	HANDLE Cons = GetStdHandle(STD_OUTPUT_HANDLE);
	if (loser == 1) {
		blablu;
		std::cout << endl << "Blue player wins in " << turns.size()/2 << " turns" << endl;
		std::cout << "Save the game log? Y/N"<<endl;
		char s;
		do
			cin >> s;
		while (s != 'y' && s != 'n');
		if (s = y) {
			ofstream log("log.txt");
			for (int i = 0; i < turns.size(); i++) {
				log << turns[i] << endl;
			}
			log.close();
		}
	}
	else {
		blared;
		std::cout << endl << "Red player wins in " << turns.size()/2+1 << " turns" << endl;
		std::cout << "Save the game log? Y/N" << endl;
		char s;
		do
			cin >> s;
		while (s != 'y' && s != 'n');
		if (s = y) {
			ofstream log("log.txt");
			for (int i = 0; i < turns.size(); i++) {
				log << turns[i] << endl;
			}
			log.close();
		}
	}
	return;
}

void TurnRed(){
	do {
		PrintField();
		cout << "Red player's turn" << endl << "Write your turn like e7-e5" << endl;
		cin >> turn;
			x = ctoi(turn[0]);
			y = ctoi(turn[1]);
			x2 = ctoi(turn[3]);
			y2 = ctoi(turn[4]);
			if (!Bad(turn, 1)) {
			int buf = field[y2][x2];
			if (field[y][x] == 41 && field[y2][x2] == 44 && y == 0) {
				if (x2 == 0) {
					field[0][2] = 41;
					field[0][3] = 44;
				}
				else {
					field[0][6] = 41;
					field[0][5] = 44;
				}
			}
			else {
				field[y2][x2] = field[y][x];
				field[y][x] = 0;
			}
			Checkcheck();
			field[y][x] = field[y2][x2];
			field[y2][x2] = buf;
		}
	} while (Bad(turn, 1) || Teammate(1) || checkred);
	if (field[y][x] == 41 && field[y2][x2] == 44 && y == 0) {
		if (x2 == 0) {
			field[0][2] = 41;
			field[0][3] = 44;}
		else {
			field[0][6] = 41;
			field[0][5] = 44;}
	}
	else {
		field[y2][x2] = field[y][x];
		field[y][x] = 0;
	}
	turns.push_back(turn);
	x3=x2;
	y3=y2;
	Checkcheck(); //���� ����: check-��� � check-��������
	Matecheck();
	if (!mate)
		TurnBlue();
	else
		GG(2);
}

void TurnBlue(){
	do{
	PrintField();	
	cout<<"Blue player's turn"<<endl<<"Write your turn like e7-e5"<<endl;
	cin>>turn;		
		x = ctoi(turn[0]);
		y = ctoi(turn[1]);
		x2 = ctoi(turn[3]);
		y2 = ctoi(turn[4]);
		if (!Bad(turn, 2)) {
		int buf = field[y2][x2];
		if (field[y][x] == 11 && field[y2][x2] == 14 && y == 7) {
			if (x2 == 0) {
				field[7][2] = 11;
				field[7][3] = 14;
			}
			else {
				field[7][6] = 11;
				field[7][5] = 14;
			}
		}
		else {
			field[y2][x2] = field[y][x];
			field[y][x] = 0;
		}
		Checkcheck();
		field[y][x] = field[y2][x2];
		field[y2][x2] = buf;
	}
	} while (Bad(turn, 2) || Teammate(2) || checkblue);
	if (field[y][x] == 11 && field[y2][x2] == 14 && y==7) {
		if (x2 == 0) {
			field[7][2] = 11;
			field[7][3] = 14;}
		else {
			field[7][6] = 11;
			field[7][5] = 14;}
	}
	else {
		field[y2][x2] = field[y][x];
		field[y][x] = 0;}
	turns.push_back(turn);
	Checkcheck();
	Matecheck();
	if (!mate)
		TurnRed();
	else
		GG(1);
}

void Launch(){
	system("cls");
	PrintField();
	return;
}

int main(){
	Launch();
	TurnRed();

	return 0;
}